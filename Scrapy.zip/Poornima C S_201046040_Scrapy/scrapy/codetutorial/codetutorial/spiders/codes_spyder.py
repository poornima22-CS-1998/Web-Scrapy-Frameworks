# -*- coding: utf-8 -*-link
import scrapy
from ..items import CodetutorialItem
class CodeSpider(scrapy.Spider):
    name='codes'
    start_urls=[
            'https://www.kashipara.com/'
            ]
    def parse(self,response):
        items = CodetutorialItem()
        title = response.css('title').extract()
        items['title'] = title
        
        all_div_codes=response.css('div.card-body')
        for codes in all_div_codes:
            
        
            Link=all_div_codes.css('a.tooltipLink').extract()
            Description = all_div_codes.css('p.card-text::text').extract()
            items['Link'] =Link
            items['Description'] = Description
            yield items
        nextpage = response.css('h3.card-title a::attr(href)').get()
        if nextpage is not None:
            yield response.follow(nextpage,callback = self.parse)
        
        
        
