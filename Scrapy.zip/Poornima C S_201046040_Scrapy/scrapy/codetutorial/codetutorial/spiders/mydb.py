# -*- coding: utf-8 -*-

import sqlite3
conn = sqlite3.connect('mycodes.db')
curr = conn.cursor()
#curr.execute("""create table codes_db(
#         title text,
#         Link text,
#         Description text
#         )""")
curr.execute("""insert into codes_db values('python','poornima','MSIS')""")
conn.commit()
conn.close()